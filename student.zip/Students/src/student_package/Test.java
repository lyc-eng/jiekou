package student_package;

public class Test {
  public static void main(String[] args) {
	Doctoral a=new Doctoral();
	a.toshow();
	a.checkmany();
	a.payment();
	a.paysalary();
	a.annual();
	a.taxamount();
	System.out.println("----------------------------");
	Doctoral b=new Doctoral();
	b.toshow();
	b.checkmany();
	b.payment();
	b.paysalary();
	b.annual1();
	b.taxamount1();
	System.out.println("----------------------------");
	Doctoral c=new Doctoral();
	c.toshow();
	c.checkmany();
	c.payment();
	c.paysalary();
	c.annual1();
	c.taxamount1();
	

}
}
